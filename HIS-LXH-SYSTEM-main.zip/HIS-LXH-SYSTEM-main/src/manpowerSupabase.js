function clean(value) {
  return String(value ?? '').trim();
}

function mapAssignmentRow(row = {}) {
  return {
    id: clean(row.ID),
    date: clean(row.Duty_Date),
    shift: clean(row.Shift),
    staffId: clean(row.Staff_ID),
    status: clean(row.Status) || 'working',
    leaveType: clean(row.Leave_Type),
    replacementStaffId: clean(row.Replacement_Staff_ID),
    note: clean(row.Note),
    createdAt: clean(row.Created_At),
    updatedAt: clean(row.Updated_At)
  };
}

function mapHistoryRow(row = {}) {
  return {
    id: clean(row.ID),
    assignmentId: clean(row.Assignment_ID),
    action: clean(row.Action),
    date: clean(row.Duty_Date),
    shift: clean(row.Shift),
    staffId: clean(row.Staff_ID),
    staffName: clean(row.Staff_Name),
    staffType: clean(row.Staff_Type),
    statusBefore: clean(row.Status_Before),
    statusAfter: clean(row.Status_After),
    leaveTypeBefore: clean(row.Leave_Type_Before),
    leaveTypeAfter: clean(row.Leave_Type_After),
    noteBefore: clean(row.Note_Before),
    noteAfter: clean(row.Note_After),
    replacementBeforeId: clean(row.Replacement_Before_ID),
    replacementBeforeName: clean(row.Replacement_Before_Name),
    replacementAfterId: clean(row.Replacement_After_ID),
    replacementAfterName: clean(row.Replacement_After_Name),
    changedAt: clean(row.Changed_At),
    changedBy: clean(row.Changed_By_Name) || clean(row.Changed_By) || '-'
  };
}

function assignmentPayload(record = {}) {
  const status = clean(record.status) || 'working';
  return {
    ID: clean(record.id) || undefined,
    Duty_Date: clean(record.date),
    Shift: clean(record.shift),
    Staff_ID: clean(record.staffId),
    Status: status,
    Leave_Type: status === 'leave' ? (clean(record.leaveType) || 'vacation') : null,
    Replacement_Staff_ID: null,
    Note: clean(record.note) || null
  };
}

function errorMessage(scope, error) {
  const details = clean(error?.details || error?.hint);
  return `${scope}: ${clean(error?.message) || 'Unknown database error'}${details ? ` (${details})` : ''}`;
}

function isOptionalManpowerColumnMissing(error) {
  const message = clean(error?.message).toLowerCase();
  return ['PGRST200', 'PGRST204', '42703'].includes(clean(error?.code).toUpperCase())
    || message.includes('leave_type')
    || message.includes('note_before')
    || message.includes('note_after');
}

export function createManpowerSupabaseBackend({ client, assignmentsTableName, historyTableName }) {
  if (!client || !assignmentsTableName || !historyTableName) throw new Error('Manpower Supabase backend requires client and table names');
  let channel = null;
  let hasLeaveTypeSchema = null;
  const assignmentColumns = 'ID,Duty_Date,Shift,Staff_ID,Status,Leave_Type,Replacement_Staff_ID,Note,Created_At,Updated_At';
  const legacyAssignmentColumns = 'ID,Duty_Date,Shift,Staff_ID,Status,Replacement_Staff_ID,Note,Created_At,Updated_At';
  const historyColumns = 'ID,Assignment_ID,Action,Duty_Date,Shift,Staff_ID,Staff_Name,Staff_Type,Status_Before,Status_After,Leave_Type_Before,Leave_Type_After,Note_Before,Note_After,Replacement_Before_ID,Replacement_Before_Name,Replacement_After_ID,Replacement_After_Name,Changed_By,Changed_By_Name,Changed_At';
  const legacyHistoryColumns = 'ID,Assignment_ID,Action,Duty_Date,Shift,Staff_ID,Staff_Name,Staff_Type,Status_Before,Status_After,Replacement_Before_ID,Replacement_Before_Name,Replacement_After_ID,Replacement_After_Name,Changed_By,Changed_By_Name,Changed_At';

  const buildAssignmentQuery = (columns, date) => {
    let query = client
      .from(assignmentsTableName)
      .select(columns)
      .is('Deleted_At', null)
      .order('Shift', { ascending: true })
      .order('Created_At', { ascending: true });
    if (clean(date)) query = query.eq('Duty_Date', clean(date));
    return query;
  };

  const requireLeaveTypeSchema = status => {
    if (hasLeaveTypeSchema === false && clean(status) !== 'working') {
      throw new Error('Supabase migration for leave types must be applied before saving a non-working status');
    }
  };

  return {
    mode: 'supabase',

    async loadAssignments(date) {
      let { data, error } = await buildAssignmentQuery(
        hasLeaveTypeSchema === false ? legacyAssignmentColumns : assignmentColumns,
        date
      );
      if (error && hasLeaveTypeSchema !== false && isOptionalManpowerColumnMissing(error)) {
        hasLeaveTypeSchema = false;
        ({ data, error } = await buildAssignmentQuery(legacyAssignmentColumns, date));
      } else if (!error && hasLeaveTypeSchema === null) hasLeaveTypeSchema = true;
      if (error) throw new Error(errorMessage('Manpower assignments', error));
      return (data || []).map(mapAssignmentRow);
    },

    async loadHistory(filters = {}) {
      const buildHistoryQuery = columns => {
        let query = client
          .from(historyTableName)
          .select(columns)
          .order('Changed_At', { ascending: false })
          .limit(2000);
        if (clean(filters.date)) query = query.eq('Duty_Date', clean(filters.date));
        if (clean(filters.shift)) query = query.eq('Shift', clean(filters.shift));
        if (clean(filters.type)) query = query.eq('Staff_Type', clean(filters.type));
        if (clean(filters.action)) query = query.eq('Action', clean(filters.action));
        return query;
      };
      let { data, error } = await buildHistoryQuery(hasLeaveTypeSchema === false ? legacyHistoryColumns : historyColumns);
      if (error && hasLeaveTypeSchema !== false && isOptionalManpowerColumnMissing(error)) {
        hasLeaveTypeSchema = false;
        ({ data, error } = await buildHistoryQuery(legacyHistoryColumns));
      }
      if (error) throw new Error(errorMessage('Manpower history', error));
      return (data || []).map(mapHistoryRow);
    },

    async create(record) {
      const payload = assignmentPayload(record);
      requireLeaveTypeSchema(payload.Status);
      if (hasLeaveTypeSchema === false) delete payload.Leave_Type;
      // Production identifiers are always generated by Postgres. Local preview
      // identifiers may not be UUIDs and must never leak into the live table.
      delete payload.ID;
      const insertAssignment = (row, columns) => client
        .from(assignmentsTableName)
        .insert(row)
        .select(columns)
        .single();
      let { data, error } = await insertAssignment(
        payload,
        hasLeaveTypeSchema === false ? legacyAssignmentColumns : assignmentColumns
      );
      if (error && hasLeaveTypeSchema !== false && isOptionalManpowerColumnMissing(error)) {
        hasLeaveTypeSchema = false;
        requireLeaveTypeSchema(payload.Status);
        delete payload.Leave_Type;
        ({ data, error } = await insertAssignment(payload, legacyAssignmentColumns));
      } else if (!error && hasLeaveTypeSchema === null) hasLeaveTypeSchema = true;
      if (error) throw new Error(errorMessage('Create manpower assignment', error));
      return mapAssignmentRow(data);
    },

    async update(id, changes = {}) {
      requireLeaveTypeSchema(changes.status);
      const payload = {
        Status: clean(changes.status) || 'working',
        Leave_Type: clean(changes.leaveType) || null,
        Replacement_Staff_ID: null,
        Note: clean(changes.note) || null
      };
      if (hasLeaveTypeSchema === false) delete payload.Leave_Type;
      const updateAssignment = (row, columns) => client
        .from(assignmentsTableName)
        .update(row)
        .eq('ID', id)
        .is('Deleted_At', null)
        .select(columns)
        .single();
      let { data, error } = await updateAssignment(
        payload,
        hasLeaveTypeSchema === false ? legacyAssignmentColumns : assignmentColumns
      );
      if (error && hasLeaveTypeSchema !== false && isOptionalManpowerColumnMissing(error)) {
        hasLeaveTypeSchema = false;
        requireLeaveTypeSchema(payload.Status);
        delete payload.Leave_Type;
        ({ data, error } = await updateAssignment(payload, legacyAssignmentColumns));
      } else if (!error && hasLeaveTypeSchema === null) hasLeaveTypeSchema = true;
      if (error) throw new Error(errorMessage('Update manpower assignment', error));
      return mapAssignmentRow(data);
    },

    async remove(id) {
      const { error } = await client
        .from(assignmentsTableName)
        .update({ Deleted_At: new Date().toISOString() })
        .eq('ID', id)
        .is('Deleted_At', null);
      if (error) throw new Error(errorMessage('Remove manpower assignment', error));
    },

    async importLocal(records = []) {
      const payload = records
        .filter(item => item?.date && item?.shift && item?.staffId)
        .map(item => {
          const row = assignmentPayload(item);
          delete row.ID;
          if (hasLeaveTypeSchema === false) delete row.Leave_Type;
          return row;
        });
      if (!payload.length) return 0;
      let imported = 0;
      // The active-assignment uniqueness rule is a partial index, which cannot
      // be targeted reliably by PostgREST upsert. Import one row at a time and
      // treat a database duplicate as an already-migrated record.
      for (const row of payload) {
        let { error } = await client.from(assignmentsTableName).insert(row);
        if (error && hasLeaveTypeSchema !== false && isOptionalManpowerColumnMissing(error)) {
          hasLeaveTypeSchema = false;
          requireLeaveTypeSchema(row.Status);
          delete row.Leave_Type;
          ({ error } = await client.from(assignmentsTableName).insert(row));
        } else if (!error && hasLeaveTypeSchema === null) hasLeaveTypeSchema = true;
        if (!error) {
          imported += 1;
          continue;
        }
        if (error.code === '23505') continue;
        throw new Error(errorMessage('Import local manpower assignments', error));
      }
      return imported;
    },

    subscribe(onChange) {
      if (channel) client.removeChannel(channel);
      channel = client
        .channel(`manpower-live-${crypto.randomUUID?.() || Date.now()}`)
        .on('postgres_changes', { event: '*', schema: 'public', table: assignmentsTableName }, payload => onChange?.('assignments', payload))
        .on('postgres_changes', { event: 'INSERT', schema: 'public', table: historyTableName }, payload => onChange?.('history', payload))
        .subscribe();
      return () => {
        if (channel) client.removeChannel(channel);
        channel = null;
      };
    }
  };
}

export { assignmentPayload, mapAssignmentRow, mapHistoryRow };
